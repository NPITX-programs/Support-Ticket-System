﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;

namespace TicketingApp
{
    internal class NewTicket
    {
        internal string Name;
        internal string AssignedPerson;
        internal string Status;
        internal string Priority;
        internal string Problem;
        internal string Workstation;
        
        

    }

}
